/*
  hydrosense_esp32_mqtt.ino — ESP32 ส่งค่าเซนเซอร์ขึ้น MQTT และรับคำสั่งควบคุมจากเว็บ
  ต้องมีไฟล์ config.h อยู่โฟลเดอร์เดียวกัน

  ไลบรารี (Arduino IDE → Library Manager):
    PubSubClient (Nick O'Leary), ArduinoJson (Benoit Blanchon เวอร์ชัน 7.x), LiquidCrystal I2C, OneWire, DallasTemperature,
    "DHT sensor library" (Adafruit) + "Adafruit Unified Sensor"
  บอร์ด: ESP32 (Arduino core 2.x ขึ้นไป)

  Topic ที่ใช้ (ทั้งหมดอยู่ใต้ TOPIC_PREFIX):
    ส่งออก  /readings        JSON {"ts":..,"ph":..,"ec":..,"water_temp":..,"air_temp":..,"humidity":..,"rssi":..} (retained)
    ส่งออก  /status          "online" / "offline" (Last Will, retained)
    ส่งออก  /state/relay1    "ON" / "OFF" (retained)      /state/led  "ON" / "OFF" (retained)
    รับเข้า  /cmd/relay1      "ON" / "OFF"
    รับเข้า  /cmd/led         "ON" / "OFF"
    รับเข้า  /cmd/test        ใดๆ → LED กระพริบ 3 ครั้ง
    รับเข้า  /cmd/calibrate   รหัสเซนเซอร์ เช่น PH-01 → พิมพ์ข้อความใน Serial (ยังไม่ได้ปรับค่าอัตโนมัติ)

  จอ LCD 1602 I2C (ตั้งค่าใน config.h): หมุน 3 หน้า — (1) pH/EC/อุณหภูมิน้ำ/อากาศ (2) ความชื้น+รีเลย์/LED (3) WiFi/MQTT/RSSI
  ไลบรารีเพิ่ม: "LiquidCrystal I2C" (ถ้าไม่ใช้จอ ตั้ง USE_LCD เป็น 0 ใน config.h ก็ไม่ต้องติดตั้ง)

  สถานะ: ยังไม่ได้คอมไพล์หรือทดสอบกับฮาร์ดแวร์/Broker จริง ทดสอบบนบอร์ดของคุณก่อนต่อรีเลย์กับโหลดจริง
*/
#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <DHT.h>
#include <time.h>
#include "config.h"
#if USE_LCD
#include <Wire.h>
#include <LiquidCrystal_I2C.h>     // ไลบรารี "LiquidCrystal I2C" (Library Manager)
#endif

OneWire ow(PIN_DS18B20);
DallasTemperature ds(&ow);
DHT dht(PIN_DHT, DHT22);
WiFiClient net;
PubSubClient mqtt(net);
#if USE_LCD
LiquidCrystal_I2C lcd(LCD_ADDR, 16, 2);   // จอ 16 ตัวอักษร 2 บรรทัด
#endif

// ค่าเซนเซอร์ล่าสุด (อ่านทุก SENSOR_MS ใช้ทั้งส่ง MQTT และแสดงจอ) NAN = อ่านไม่ได้
float gPh = NAN, gEc = NAN, gWt = NAN, gAt = NAN, gHu = NAN;
unsigned long lastSensor = 0, lastLcd = 0, lastPage = 0; uint8_t lcdPage = 0;

String tReadings, tStatus, tStateBase, tCmdBase, clientId;
bool relayOn = false, ledOn = false;
unsigned long relayOnAt = 0, lastPub = 0, lastWifiTry = 0, lastWifiOk = 0, lastMqttTry = 0, mqttBackoff = 2000;
int blinkLeft = 0; unsigned long lastBlink = 0;                // สำหรับคำสั่ง /cmd/test
bool prefixOk = true;

// ---------------- อ่านเซนเซอร์ ----------------
float readMv(int pin) {                                        // median ของ 25 ตัวอย่าง ลดสัญญาณรบกวน
  uint32_t s[25];
  for (int i = 0; i < 25; i++) { s[i] = analogReadMilliVolts(pin); delay(4); }
  for (int i = 1; i < 25; i++) { uint32_t k = s[i]; int j = i - 1; while (j >= 0 && s[j] > k) { s[j + 1] = s[j]; j--; } s[j + 1] = k; }
  return (float)s[12];
}
float readWaterTemp() {                                        // DS18B20
  ds.requestTemperatures();
  float t = ds.getTempCByIndex(0);
  return (t == DEVICE_DISCONNECTED_C || t < -20 || t > 80) ? NAN : t;
}
float readAirTemp()  { float t = dht.readTemperature(); return isnan(t) ? NAN : t; }   // DHT22
float readHumidity() { float h = dht.readHumidity();    return isnan(h) ? NAN : h; }
float readPh() {                                               // เส้นตรงผ่านจุด pH7 และ pH4
  float mv = readMv(PIN_PH);
  if (mv < 50) return NAN;                                     // ไม่ได้ต่อโพรบ/สายหลุด
  float ph = 7.0f + ((4.0f - 7.0f) / (PH_MV_AT_4 - PH_MV_AT_7)) * (mv - PH_MV_AT_7);
  return (ph < 0 || ph > 14) ? NAN : ph;
}
float readEc(float waterTempC) {                               // เส้นตรงผ่านจุดศูนย์ + ชดเชยอุณหภูมิ (ประมาณการ)
  float mv = readMv(PIN_EC);
  if (mv < 20) return NAN;
  float ec = (EC_STD_MS_CM / EC_STD_MV) * mv;
  float t = isnan(waterTempC) ? EC_STD_TEMP_C : waterTempC;
  return ec / (1.0f + EC_TEMP_COEFF * (t - EC_STD_TEMP_C));
}

void readAll() {                                               // อ่านเซนเซอร์ทั้งหมดเก็บไว้ในตัวแปร g* (ใช้เวลาประมาณ 1 วินาที)
  gWt = readWaterTemp();
  gPh = readPh();
  gEc = readEc(gWt);
  gAt = readAirTemp();
  gHu = readHumidity();
}

// ใส่ค่าลง JSON: อ่านไม่ได้ → null (เว็บจะแสดง "—" ไม่เดาค่า)
void setf(JsonDocument &d, const char *k, float v, int dec) {
  if (isnan(v)) d[k] = nullptr; else d[k] = serialized(String(v, dec));
}

// ---------------- จอ LCD 1602 (แสดงได้เฉพาะ ASCII ไม่รองรับภาษาไทย) ----------------
#if USE_LCD
String fv(float v, int d) { return isnan(v) ? String("--") : String(v, d); }
void lcdLine(uint8_t row, const char *fmt, ...) {              // เขียนทั้งบรรทัด 16 ช่อง (เติมช่องว่างลบข้อความเก่า)
  char b[40]; va_list ap; va_start(ap, fmt); vsnprintf(b, sizeof(b), fmt, ap); va_end(ap);
  char o[17]; snprintf(o, sizeof(o), "%-16s", b);
  lcd.setCursor(0, row); lcd.print(o);
}
#endif

// ---------------- สถานะอุปกรณ์ ----------------
void publishState(const char *name, bool on) {
  if (!mqtt.connected()) return;
  mqtt.publish((tStateBase + name).c_str(), on ? "ON" : "OFF", true);
}
void setRelay(bool on) {
  relayOn = on;
  digitalWrite(PIN_RELAY, on ? RELAY_ON_LEVEL : !RELAY_ON_LEVEL);
  if (on) relayOnAt = millis();
  publishState("relay1", on);
}
void setLed(bool on) {
  ledOn = on;
  digitalWrite(PIN_LED, on ? LED_ON_LEVEL : !LED_ON_LEVEL);
  publishState("led", on);
}

// ---------------- รับคำสั่งจากเว็บ ----------------
void onMsg(char *topic, byte *payload, unsigned int len) {
  char val[24];
  if (len == 0 || len >= sizeof(val)) return;
  memcpy(val, payload, len); val[len] = 0;
  String t(topic);
  if (!t.startsWith(tCmdBase)) return;
  String name = t.substring(tCmdBase.length());
  bool on = (strcmp(val, "ON") == 0), off = (strcmp(val, "OFF") == 0);
  Serial.printf("คำสั่ง: %s = %s\n", name.c_str(), val);
  if (name == "relay1")      { if (on) setRelay(true); else if (off) setRelay(false); }
  else if (name == "led")    { if (on) setLed(true);   else if (off) setLed(false); }
  else if (name == "test")   { blinkLeft = 6; lastBlink = 0; }
  else if (name == "calibrate") { Serial.printf("ได้รับคำสั่งสอบเทียบ %s — แก้ค่าใน config.h แล้วอัปโหลดใหม่ (ยังไม่ปรับอัตโนมัติ)\n", val); }
}

// ---------------- เครือข่าย (ไม่บล็อกโปรแกรม เชื่อมต่อใหม่อัตโนมัติ) ----------------
void maintainWifi() {
  if (WiFi.status() == WL_CONNECTED) { lastWifiOk = millis(); return; }
  if (millis() - lastWifiTry < 10000) return;
  lastWifiTry = millis();
  Serial.println("Wi-Fi หลุด — กำลังต่อใหม่");
  WiFi.disconnect(); WiFi.begin(WIFI_SSID, WIFI_PASS);
  if (millis() - lastWifiOk > 600000UL) ESP.restart();         // หลุดเกิน 10 นาที → รีสตาร์ตบอร์ด
}
void maintainMqtt() {
  if (!prefixOk || mqtt.connected() || WiFi.status() != WL_CONNECTED) return;
  if (millis() - lastMqttTry < mqttBackoff) return;
  lastMqttTry = millis();
  Serial.print("ต่อ MQTT... ");
  bool ok = mqtt.connect(clientId.c_str(), MQTT_USER[0] ? MQTT_USER : nullptr, MQTT_PASS[0] ? MQTT_PASS : nullptr,
                         tStatus.c_str(), 1, true, "offline");   // Last Will: ถ้าบอร์ดหลุดเงียบๆ Broker ประกาศ offline ให้เว็บ
  if (ok) {
    Serial.println("สำเร็จ");
    mqttBackoff = 2000;
    mqtt.publish(tStatus.c_str(), "online", true);
    mqtt.subscribe((tCmdBase + "#").c_str(), 1);
    publishState("relay1", relayOn); publishState("led", ledOn);   // รายงานสถานะปัจจุบันหลังต่อได้
  } else {
    Serial.printf("ล้มเหลว state=%d\n", mqtt.state());
    mqttBackoff = min(mqttBackoff * 2, 30000UL);               // รอนานขึ้นเรื่อยๆ สูงสุด 30 วินาที
  }
}

#if USE_LCD
void updateLcd() {
  if (!prefixOk) { lcdLine(0, "Set TOPIC_PREFIX"); lcdLine(1, "in config.h"); return; }
  switch (lcdPage) {
    case 0:  // หน้า 1: pH, EC, อุณหภูมิน้ำ, อุณหภูมิอากาศ
      lcdLine(0, "pH:%s EC:%s", fv(gPh, 2).c_str(), fv(gEc, 2).c_str());
      lcdLine(1, "W:%sC A:%sC", fv(gWt, 1).c_str(), fv(gAt, 1).c_str());
      break;
    case 1:  // หน้า 2: ความชื้น และสถานะรีเลย์/LED
      lcdLine(0, "Hum:%s%%", fv(gHu, 0).c_str());
      lcdLine(1, "Rly:%s LED:%s", relayOn ? "ON" : "OFF", ledOn ? "ON" : "OFF");
      break;
    default: // หน้า 3: สถานะเครือข่าย
      lcdLine(0, "WiFi:%s MQTT:%s", WiFi.status() == WL_CONNECTED ? "OK" : "--", mqtt.connected() ? "OK" : "--");
      if (WiFi.status() == WL_CONNECTED) lcdLine(1, "RSSI:%ddBm", WiFi.RSSI()); else lcdLine(1, "No WiFi");
  }
}
#endif

void publishReadings() {
  JsonDocument doc;
  time_t now = time(nullptr);
  if (now > 1700000000) doc["ts"] = (uint32_t)now;             // มีเวลาจริงจาก NTP จึงใส่ ts (ไม่มี = เว็บใช้เวลาที่รับ)
  setf(doc, "ph", gPh, 2);                                      // ใช้ค่าที่อ่านล่าสุด (readAll)
  setf(doc, "ec", gEc, 2);
  setf(doc, "water_temp", gWt, 1);
  setf(doc, "air_temp", gAt, 1);
  setf(doc, "humidity", gHu, 0);
  doc["rssi"] = WiFi.RSSI();
  char buf[256];
  size_t n = serializeJson(doc, buf, sizeof(buf));
  if (n == 0 || n >= sizeof(buf)) return;
  mqtt.publish(tReadings.c_str(), buf, true);                  // retained: เว็บที่เปิดทีหลังได้ค่าล่าสุดทันที
  Serial.println(buf);
}

void handleSerial() {                                          // พิมพ์ raw ใน Serial Monitor เพื่อดูแรงดันดิบสำหรับ calibrate
  if (!Serial.available()) return;
  String c = Serial.readStringUntil('\n'); c.trim();
#if USE_LCD
  if (c == "scan") {                                            // ค้นหาที่อยู่ I2C ของจอ
    int n = 0;
    for (uint8_t a = 1; a < 127; a++) { Wire.beginTransmission(a); if (Wire.endTransmission() == 0) { Serial.printf("พบอุปกรณ์ I2C ที่ 0x%02X\n", a); n++; } }
    if (!n) Serial.println("ไม่พบอุปกรณ์ I2C — ตรวจสาย SDA/SCL/VCC/GND");
  }
#endif
  if (c == "raw")
    Serial.printf("pH: %.0f mV | EC: %.0f mV | น้ำ: %.2f C | อากาศ: %.1f C | ชื้น: %.0f %%\n",
                  readMv(PIN_PH), readMv(PIN_EC), readWaterTemp(), readAirTemp(), readHumidity());
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_RELAY, OUTPUT); digitalWrite(PIN_RELAY, !RELAY_ON_LEVEL);   // เริ่มต้นปิดรีเลย์เสมอ
  pinMode(PIN_LED, OUTPUT);   digitalWrite(PIN_LED, !LED_ON_LEVEL);
  analogSetPinAttenuation(PIN_PH, ADC_11db);
  analogSetPinAttenuation(PIN_EC, ADC_11db);
  ds.begin(); dht.begin();
#if USE_LCD
  Wire.begin(PIN_SDA, PIN_SCL);
  lcd.init(); lcd.backlight();
  lcdLine(0, "HydroSense"); lcdLine(1, "Starting...");
#endif

  String base = String(TOPIC_PREFIX);
  prefixOk = base.indexOf("CHANGE-ME") < 0 && base.length() > 0;
  if (!prefixOk) Serial.println("!! ตั้ง TOPIC_PREFIX ใน config.h ก่อน (ห้ามใช้ CHANGE-ME) — บอร์ดจะยังไม่ต่อ MQTT");
  tReadings = base + TOPIC_READINGS; tStatus = base + TOPIC_STATUS;
  tStateBase = base + TOPIC_STATE;   tCmdBase = base + TOPIC_CMD;
  clientId = String(CLIENT_ID_PREFIX) + String((uint32_t)(ESP.getEfuseMac() >> 16), HEX);

  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  lastWifiOk = millis();
  configTime(0, 0, "pool.ntp.org", "time.google.com");         // เวลาจริงสำหรับ ts
  mqtt.setServer(MQTT_HOST, MQTT_PORT);
  mqtt.setCallback(onMsg);
  mqtt.setBufferSize(512);
  mqtt.setKeepAlive(30);
  Serial.println("Client ID: " + clientId);
  readAll();                                                   // อ่านค่าครั้งแรกให้มีข้อมูลก่อนแสดงจอ/ส่งครั้งแรก
  lastSensor = lastLcd = lastPage = millis();
}

void loop() {
  maintainWifi();
  maintainMqtt();
  mqtt.loop();
  handleSerial();

  if (millis() - lastSensor >= SENSOR_MS) { lastSensor = millis(); readAll(); }   // อ่านเซนเซอร์เป็นรอบ (บล็อกประมาณ 1 วินาที)
#if USE_LCD
  if (millis() - lastPage >= LCD_PAGE_MS) { lastPage = millis(); lcdPage = (lcdPage + 1) % 3; }   // สลับหน้าจอ
  if (millis() - lastLcd >= 500) { lastLcd = millis(); updateLcd(); }
#endif

  if (relayOn && RELAY_MAX_ON_MS > 0 && millis() - relayOnAt >= RELAY_MAX_ON_MS) {   // ตัดรีเลย์เมื่อเปิดค้างนานเกินกำหนด
    Serial.println("รีเลย์เปิดนานเกินกำหนด — ปิดอัตโนมัติ");
    setRelay(false);
  }
  if (blinkLeft > 0 && millis() - lastBlink >= 150) {          // กระพริบ LED สำหรับ /cmd/test (ไม่บล็อก)
    lastBlink = millis(); blinkLeft--;
    digitalWrite(PIN_LED, (blinkLeft % 2) ? LED_ON_LEVEL : !LED_ON_LEVEL);
    if (blinkLeft == 0) digitalWrite(PIN_LED, ledOn ? LED_ON_LEVEL : !LED_ON_LEVEL);
  }
  if (mqtt.connected() && millis() - lastPub >= PUBLISH_MS) {
    lastPub = millis();
    publishReadings();
  }
}
