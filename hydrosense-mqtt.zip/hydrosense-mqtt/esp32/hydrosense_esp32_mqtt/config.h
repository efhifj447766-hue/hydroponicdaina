// ===== config.h — ไฟล์ตั้งค่าฝั่ง ESP32 (แก้ที่ไฟล์นี้ไฟล์เดียว) =====
// ค่าที่มีเครื่องหมาย [ต้องตรงกับเว็บ] ต้องเหมือนใน web/js/config.js ทุกตัวอักษร (ตัวพิมพ์เล็ก/ใหญ่ต่างกัน)
#pragma once

// ---------- Wi-Fi ----------
#define WIFI_SSID   "ชื่อ-WiFi"                 // ชื่อ Wi-Fi 2.4 GHz ที่บอร์ดจะต่อ (ESP32 ไม่รองรับ 5 GHz)
#define WIFI_PASS   "รหัส-WiFi"

// ---------- MQTT Broker (TCP ธรรมดา สำหรับบอร์ด) ----------
#define MQTT_HOST   "broker.emqx.io"            // [ต้องตรงกับเว็บ: MQTT.HOST] ที่อยู่ Broker
#define MQTT_PORT   1883                        // พอร์ต TCP ของบอร์ด (เว็บใช้ 8083/8084 ซึ่งเป็นพอร์ต WebSocket ของ Broker ตัวเดียวกัน)
#define MQTT_USER   ""                          // broker.emqx.io สาธารณะเว้นว่าง; ถ้าใช้ EMQX Cloud ของตัวเองใส่ username ที่สร้างไว้
#define MQTT_PASS   ""

// Client ID ของบอร์ด = คำนำหน้านี้ + เลขจากชิป (ไม่ซ้ำกันทุกบอร์ด) ห้ามซ้ำกับ Client ID อื่นบน Broker เดียวกัน
#define CLIENT_ID_PREFIX "hs-esp32-"

// ---------- Topic ----------
// [ต้องตรงกับเว็บ: MQTT.TOPIC_PREFIX] ตั้งเป็นค่าสุ่มของคุณเอง เช่น "hydrosense/k7f3q9x2"
// broker สาธารณะใครก็ subscribe/publish ได้ ถ้าใช้ชื่อซ้ำหรือเดาง่ายคนอื่นจะอ่านค่าและสั่งอุปกรณ์ของคุณได้
#define TOPIC_PREFIX   "hydrosense/CHANGE-ME"
// [ต้องตรงกับเว็บ: MQTT.TOPICS.*] ส่วนต่อท้าย (ถ้าไม่ได้แก้ในเว็บ ก็ไม่ต้องแก้ที่นี่)
#define TOPIC_READINGS "/readings"              // บอร์ดส่งค่าเซนเซอร์ (JSON, retained)
#define TOPIC_STATUS   "/status"                // "online"/"offline" (Last Will, retained)
#define TOPIC_STATE    "/state/"                // สถานะ ON/OFF ของอุปกรณ์ เช่น /state/relay1 (retained)
#define TOPIC_CMD      "/cmd/"                  // คำสั่งจากเว็บ เช่น /cmd/relay1, /cmd/led, /cmd/test, /cmd/calibrate

#define PUBLISH_MS  30000UL                     // ส่งค่าเซนเซอร์ทุกกี่ มิลลิวินาที (30 วินาที ตรงกับกราฟ)

// ---------- ขา GPIO (ค่าเริ่มต้นเป็นข้อเสนอ — ตรวจให้ตรงกับบอร์ดและการต่อสายจริงของคุณ) ----------
// ใช้ขา ADC1 (GPIO32–39) สำหรับแอนะล็อก เพราะ ADC2 ใช้ไม่ได้ขณะเปิด Wi-Fi
#define PIN_DS18B20 4      // DATA ของ DS18B20 (อุณหภูมิน้ำ) + ตัวต้านทาน pull-up 4.7 kΩ ไป 3.3 V
#define PIN_DHT     5      // DATA ของ DHT22 (อุณหภูมิ/ความชื้นอากาศ)
#define PIN_PH      34     // เอาต์พุตแอนะล็อกของโมดูล pH
#define PIN_EC      35     // เอาต์พุตแอนะล็อกของโมดูล EC
#define PIN_RELAY   26     // ขาควบคุมรีเลย์ 1
#define PIN_LED     2      // LED ทดสอบ (LED บนบอร์ด ESP32 ส่วนใหญ่อยู่ที่ GPIO2)
// ขา ADC รับแรงดันได้ไม่เกิน 3.3 V ถ้าโมดูลจ่ายสูงกว่านี้ต้องแบ่งแรงดันก่อน (ดู datasheet ของรุ่นที่ใช้)

// ---------- จอ LCD 1602 แบบ I2C (โมดูลมี backpack PCF8574 4 ขา: GND, VCC, SDA, SCL) ----------
#define USE_LCD        1            // 1 = ใช้จอ, 0 = ไม่ใช้ (ตัดโค้ดจอออกทั้งหมด)
#define LCD_ADDR       0x27         // ที่อยู่ I2C ส่วนใหญ่ 0x27 หรือ 0x3F ถ้าจอไม่ขึ้น พิมพ์ "scan" ใน Serial Monitor เพื่อหาที่อยู่จริง
#define PIN_SDA        21           // ขา SDA ของ I2C (ค่าเริ่มต้น ESP32 = 21)
#define PIN_SCL        22           // ขา SCL ของ I2C (ค่าเริ่มต้น ESP32 = 22)
#define SENSOR_MS      5000UL       // อ่านเซนเซอร์ทุกกี่ ms เพื่ออัปเดตจอ (การส่ง MQTT ยังตาม PUBLISH_MS)
#define LCD_PAGE_MS    3000UL       // สลับหน้าจอทุกกี่ ms

// ---------- รีเลย์/LED ----------
#define RELAY_ON_LEVEL   HIGH       // โมดูลรีเลย์ส่วนใหญ่ "active-LOW" ให้ตรวจสเปกโมดูลของคุณ ถ้าเปิดเมื่อสั่ง LOW ให้เปลี่ยนเป็น LOW
#define LED_ON_LEVEL     HIGH
#define RELAY_MAX_ON_MS  600000UL   // ตัดรีเลย์เองเมื่อเปิดค้างเกินเวลานี้ (10 นาที) กันปั๊มทำงานค้าง; ตั้ง 0 = ปิดฟีเจอร์นี้

// ---------- ค่า Calibrate (วัดจริงด้วยน้ำยามาตรฐาน แล้วกรอกที่นี่) ----------
// พิมพ์ "raw" ใน Serial Monitor (115200) เพื่อดูแรงดันดิบ (mV) ตอนจุ่มน้ำยา
#define PH_MV_AT_7     1500.0       // << แทนด้วยค่าที่วัดได้จริงตอนจุ่มน้ำยา pH 7.00
#define PH_MV_AT_4     2030.0       // << แทนด้วยค่าที่วัดได้จริงตอนจุ่มน้ำยา pH 4.00
#define EC_STD_MS_CM   1.413        // ค่า EC ของน้ำยามาตรฐานที่ใช้ (mS/cm)
#define EC_STD_MV      800.0        // << แทนด้วยค่าที่วัดได้จริงตอนจุ่มน้ำยา EC มาตรฐาน
#define EC_STD_TEMP_C  25.0         // อุณหภูมิน้ำยาตอน calibrate
#define EC_TEMP_COEFF  0.02         // ชดเชยอุณหภูมิโดยประมาณ 2%/°C (ตรวจกับคู่มือโพรบของคุณ)
